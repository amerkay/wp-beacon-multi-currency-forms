# Duplicator Archive

To backup, install "Duplicator" free version. Backup the Wordpress Instance, download both `archive_xxx.zip` and `installer.php` files and place them in this directory.